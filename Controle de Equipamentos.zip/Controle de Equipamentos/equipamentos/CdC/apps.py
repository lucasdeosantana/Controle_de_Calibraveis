from django.apps import AppConfig


class CdcConfig(AppConfig):
    name = 'CdC'
